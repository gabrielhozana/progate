# Tetapkan " adalah sebuah bahasa pemrograman yang mengagumkan" pada variable text
text = " adalah sebuah bahasa pemrograman yang mengagumkan"

# Gabungkan string-string dibawah ini dengan variable text dan cetaklah hasilnya
puts "Ruby" + text
puts "Python"+ text
puts "Java"+ text