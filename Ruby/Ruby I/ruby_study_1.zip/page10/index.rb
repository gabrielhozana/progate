length = 9
width = 8
puts width
puts length * width

puts "----"
# Perbarui variable width dengan menambahkan 5 pada dirinya
width +=5

puts width
puts length * width
