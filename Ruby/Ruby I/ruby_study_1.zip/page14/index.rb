score = 100

# Jika nilai `score` adalah 100, cetak "Bagus sekali!"
if score == 100 
  puts "Bagus sekali!"
end
# Jika nilai `score` tidak bernilai 100, cetak "Anda bisa lebih baik lagi!"
if score != 100
  puts "Anda bisa lebih baik lagi!"
end