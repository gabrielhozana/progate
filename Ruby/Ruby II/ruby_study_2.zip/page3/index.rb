languages = ["Jepang", "Inggris", "Spanyol"]

# Dapatkan masing masing element dari variable `languages` menggunakan method `each`,
# kemudian cetak "Saya bisa berbahasa ____"
languages.each do |language|
  puts "Saya bisa berbahasa #{language}"
end