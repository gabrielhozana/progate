languages = ["Jepang", "Inggris", "Spanyol"]

# Cetak element pada indeks 1
puts languages[1]

# Cetak "Saya bisa berbahasa ____" menggunakan element pada index 0
puts "Saya bisa berbahasa #{languages[0]} "
