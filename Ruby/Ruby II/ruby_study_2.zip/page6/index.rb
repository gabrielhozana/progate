exam = {"subject" => "Matematika", "score" => 80}

# Cetak nilai dari element dengan kunci "subject"
puts exam["subject"]

# Perbarui nilai dari element dengan kunci "subject" menjadi "Ilmu Pengetahuan Alam"
exam["subject"] = "Ilmu Pengetahuan Alam"

# Cetak lagi nilai dari element dengan kunci "subject"
puts exam["subject"]

# Tambahkan sebuah element dengan kunci "grade" dan nilai "B"
exam["grade"] = "B"

# Cetak nilai dari element dengan kunci "grade"
puts exam["grade"]
